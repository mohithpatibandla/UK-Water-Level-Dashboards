import requests
from bs4 import BeautifulSoup
import json
import os
import re
from datetime import datetime

WIKI_URL = "https://en.wikipedia.org/wiki/List_of_reservoirs_in_the_United_Kingdom"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

def fetch_html(url: str) -> str:
    r = requests.get(url, headers=HEADERS, timeout=20)
    print(f"GET {url} -> {r.status_code}")
    r.raise_for_status()
    return r.text

def clean_text(s: str) -> str:
    # remove [1], [i], etc. and compress whitespace
    s = re.sub(r"\[[^\]]*\]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def to_int_or_none(s: str):
    s = clean_text(s)
    if not s or s.lower() in {"na", "n/a", "-", "—"}:
        return None
    digits = re.sub(r"[^\d]", "", s)
    return int(digits) if digits else None

def header_index_map(header_cells):
    """
    Map key columns to indexes. Be liberal with matching because
    Wikipedia headers can vary and use m³, m3, etc.
    """
    idx = {}
    headers = [clean_text(h.get_text(" ", strip=True)).lower() for h in header_cells]

    for i, h in enumerate(headers):
        if "rank" in h:
            idx["rank"] = i
        if any(k in h for k in ("name", "reservoir")):
            idx["name"] = i
        if "country" in h:
            idx["country"] = i
        if any(k in h for k in ("county", "region", "area", "district")):
            idx["county"] = i
        # volume: match broadly – maximum, volume, capacity; allow m3/m³/m^3 but don't require it
        if any(k in h for k in ("maximum", "max", "volume", "capacity")):
            idx["volume"] = i
        if ("planning" in h and "date" in h):
            idx["planning_date"] = i
        if ("completion" in h and "date" in h):
            idx["completion_date"] = i
        if any(k in h for k in ("location", "coordinate", "grid ref")):
            idx["location"] = i
    return idx

def extract_name(td):
    a = td.find("a", href=True)
    if a and a.get_text(strip=True):
        return clean_text(a.get_text(strip=True))
    return clean_text(td.get_text(" ", strip=True))

def text_has_degrees(txt: str) -> bool:
    txt = txt.lower()
    return ("°" in txt) or any(d in txt for d in [" n", " s", " e", " w"])

def guess_volume_from_row(cells) -> int | None:
    """
    Fallback: pick the largest plausible integer (>= 100,000) in the row,
    ignoring cells that look like coordinates or obvious non-volume text.
    """
    candidates = []
    for td in cells:
        txt = clean_text(td.get_text(" ", strip=True))
        if not txt or text_has_degrees(txt):
            continue
        # find big numbers like 39,000,000 or 1838000
        for m in re.findall(r"\d{1,3}(?:,\d{3})+|\d{6,}", txt):
            val = int(re.sub(r"[^\d]", "", m))
            if val >= 100_000:  # volumes are in millions typically
                candidates.append(val)
    # return the max plausible value if any
    return max(candidates) if candidates else None

def parse_tables(soup: BeautifulSoup):
    results = []
    for table in soup.find_all("table", class_="wikitable"):
        rows = table.find_all("tr")
        if len(rows) < 2:
            continue

        header_cells = rows[0].find_all(["th", "td"])
        colmap = header_index_map(header_cells)

        for row in rows[1:]:
            # include th as some rows use <th scope="row"> inside body
            cells = row.find_all(["td", "th"])
            if not cells:
                continue

            geo = row.find("span", class_="geo")
            if not geo or ";" not in geo.get_text(strip=True):
                continue

            lat_str, lon_str = [p.strip() for p in geo.get_text(strip=True).split(";", 1)]
            try:
                lat = float(lat_str); lon = float(lon_str)
            except ValueError:
                continue

            def get_cell(idx_key):
                i = colmap.get(idx_key, None)
                return cells[i] if i is not None and i < len(cells) else None

            # name
            name = None
            name_td = get_cell("name")
            if name_td:
                name = extract_name(name_td)
            if not name:
                # fallback: first cell with letters (not pure number)
                for td in cells:
                    txt = clean_text(td.get_text(" ", strip=True))
                    if txt and re.search(r"[A-Za-z]", txt) and not txt.isdigit():
                        name = txt
                        break
            if not name:
                continue

            # other simple fields
            rank = clean_text(get_cell("rank").get_text(" ", strip=True)) if get_cell("rank") else None
            country = clean_text(get_cell("country").get_text(" ", strip=True)) if get_cell("country") else None
            county = clean_text(get_cell("county").get_text(" ", strip=True)) if get_cell("county") else None
            planning_date = clean_text(get_cell("planning_date").get_text(" ", strip=True)) if get_cell("planning_date") else None
            completion_date = clean_text(get_cell("completion_date").get_text(" ", strip=True)) if get_cell("completion_date") else None

            # volume: try header-mapped cell first
            max_volume_m3 = None
            vol_td = get_cell("volume")
            if vol_td:
                volume_raw = clean_text(vol_td.get_text(" ", strip=True))
                max_volume_m3 = to_int_or_none(volume_raw)

            # fallback: scan the row and pick the biggest plausible number
            if max_volume_m3 is None:
                max_volume_m3 = guess_volume_from_row(cells)

            results.append({
                "rank": rank or None,
                "name": name,
                "country": country or None,
                "county": county or None,
                "latitude": lat,
                "longitude": lon,
                "maxVolume_m3": max_volume_m3,
                "planningDate": planning_date or None,
                "completionDate": completion_date or None,
            })
    return results

def save_json(data, folder="uk_dam_data"):
    os.makedirs(folder, exist_ok=True)
    live_path = os.path.join(folder, "live.json")
    payload = {
        "lastUpdate": datetime.now().strftime("%Y-%m-%d"),
        "dams": data,
    }
    with open(live_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=4, ensure_ascii=False)
    print(f"Saved data to {live_path}")

if __name__ == "__main__":
    html = fetch_html(WIKI_URL)
    soup = BeautifulSoup(html, "html.parser")
    dams = parse_tables(soup)
    print(f"Extracted rows: {len(dams)}")
    for d in dams[:8]:
        print("->", d["name"], d["maxVolume_m3"])
    save_json(dams)
