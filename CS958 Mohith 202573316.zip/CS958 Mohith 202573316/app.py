
from flask import Flask, render_template, jsonify, Response
import json, os, csv, requests
from datetime import datetime, timedelta

app = Flask(__name__)

# OpenWeatherMap key (current weather). Historical uses.
OPENWEATHER_KEY = "22eb3a64b1c4dd75e402d514901484cf"

def live_json_path():
    return os.path.join(app.root_path, "uk_dam_data", "live.json")

def load_data():
    p = live_json_path()
    if not os.path.exists(p):
        return {"lastUpdate": "N/A", "dams": []}
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

# ---------- helpers ----------

def fetch_current_weather(lat: float, lon: float):
    """OpenWeather current conditions (needs your key). Returns dict or None."""
    if not OPENWEATHER_KEY or OPENWEATHER_KEY == "YOUR_API_KEY":
        return None
    try:
        url = (
            "https://api.openweathermap.org/data/2.5/weather"
            f"?lat={lat}&lon={lon}&appid={OPENWEATHER_KEY}&units=metric"
        )
        r = requests.get(url, timeout=12)
        if r.status_code == 200:
            return r.json()
        else:
            # print brief debug; don't crash the page
            print("OpenWeather error:", r.status_code, r.text[:200])
            return None
    except Exception as e:
        print("OpenWeather exception:", e)
        return None

def fetch_historical_weather(lat: float, lon: float, days: int = 60):
    """
    Open-Meteo daily history (no key). Returns dict with lists:
      dates, tmax, tmin, precip
    """
    # Open-Meteo supports past_days up to ~92 reliably
    days = max(1, min(days, 92))
    try:
        url = (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum"
            f"&past_days={days}&forecast_days=0&timezone=auto"
        )
        r = requests.get(url, timeout=15)
        if r.status_code != 200:
            print("Open-Meteo error:", r.status_code, r.text[:200])
            return None
        j = r.json()
        d = j.get("daily", {})
        dates = d.get("time", []) or []
        tmax = d.get("temperature_2m_max", []) or []
        tmin = d.get("temperature_2m_min", []) or []
        precip = d.get("precipitation_sum", []) or []
        # keep aligned length
        n = min(len(dates), len(tmax), len(tmin), len(precip))
        return {
            "dates": dates[-n:],
            "tmax": tmax[-n:],
            "tmin": tmin[-n:],
            "precip": precip[-n:],
        }
    except Exception as e:
        print("Open-Meteo exception:", e)
        return None

def synthesize_water_levels(max_volume_m3: int | None, hist: dict | None):
    """
    Create a plausible daily water-level time series using a simple mass-balance idea:
      level%(t) = level%(t-1) + a * precip(mm) - b * max(0, tmax-12)
    Clamp to [35, 98].
    Returns dict: { dates, level_pct, level_m3, current_pct, current_m3 }
    """
    if not max_volume_m3 or not hist:
        return None

    dates = hist["dates"]
    precip = hist["precip"]
    tmax = hist["tmax"]

    if not dates:
        return None

    a = 0.18   # inflow sensitivity per mm
    b = 0.10   # evaporation/usage sensitivity per °C above baseline
    baseline = 12.0  # °C baseline where evaporation starts to dominate
    level = 70.0     # start from 70% full

    level_pct = []
    level_m3 = []

    for i in range(len(dates)):
        rain = float(precip[i] or 0.0)
        t = float(tmax[i] or baseline)
        delta = a * rain - b * max(0.0, t - baseline)
        level = max(35.0, min(98.0, level + delta))
        level_pct.append(round(level, 2))
        level_m3.append(int((level / 100.0) * (max_volume_m3 or 0)))

    return {
        "dates": dates,
        "level_pct": level_pct,
        "level_m3": level_m3,
        "current_pct": level_pct[-1],
        "current_m3": level_m3[-1],
    }

# ---------- routes ----------

@app.route("/")
def index():
    return render_template("index.html", data=load_data())

@app.route("/dam/<name>")
def dam_dashboard(name):
    data = load_data()
    dam = next((d for d in data.get("dams", []) if d["name"] == name), None)
    if not dam:
        return f"<h2>Dam '{name}' not found</h2>", 404

    lat, lon = dam.get("latitude"), dam.get("longitude")
    weather = None
    hist = None
    water = None

    if lat is not None and lon is not None:
        try:
            lat = float(lat); lon = float(lon)
        except:
            lat = lon = None

    if lat is not None and lon is not None:
        # current weather (OpenWeather) 
        weather = fetch_current_weather(lat, lon)
        # historical daily (Open-Meteo)
        hist = fetch_historical_weather(lat, lon, days=60)
        # Reservoir level series from historical weather
        water = synthesize_water_levels(dam.get("maxVolume_m3"), hist)

    return render_template(
        "dashboard.html",
        dam=dam,
        weather=weather,
        hist=hist,
        water=water
    )

@app.route("/api/data")
def api_data():
    return jsonify(load_data())

@app.route("/download/json")
def download_json():
    payload = load_data()
    return Response(
        json.dumps(payload, ensure_ascii=False, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": "attachment; filename=uk_reservoirs.json"}
    )

@app.route("/download/csv")
def download_csv():
    payload = load_data()
    rows = payload.get("dams", [])
    headers = ["rank","name","country","county","latitude","longitude","maxVolume_m3","planningDate","completionDate"]

    def generate():
        yield ",".join(headers) + "\n"
        for r in rows:
            line = [str(r.get(h, "")).replace(",", " ") for h in headers]
            yield ",".join(line) + "\n"

    return Response(
        generate(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=uk_reservoirs.csv"}
    )

if __name__ == "__main__":
    app.run(debug=True)
